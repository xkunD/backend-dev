Name: Xiaokun Du	
NetID: xd239

Working Endpoint: <GET /api/courses/>
Your Server Address: http://34.86.120.32

Questions:
Explain the concept of deployment in your own words.

Deployment is the process of putting a software application onto a server or other environment where users can actually use it. It moves the software from being a development project to a live application.

What are environment variables?

Environment variables are settings that tell your computer how to behave for different applications. They store information like where to find files or which settings to use, without changing the program's code.

What is the filename of the file where environment variables are traditionally stored?

.env

What is the network protocol we use to access servers?

The most common protocol for accessing servers is TCP (Transmission Control Protocol). It ensures data is sent reliably and in order over the internet.

Explain the concept of clustering in your own words.

Clustering means linking several computers or servers together so they act like one big machine. This helps handle more tasks at once and keeps the system running even if one server fails.

Explain the concept of load balancing in your own words.

Load balancing is about spreading tasks across several computers or servers so that no single one gets overloaded. This helps make applications run faster and more reliably by managing traffic and workload efficiently.